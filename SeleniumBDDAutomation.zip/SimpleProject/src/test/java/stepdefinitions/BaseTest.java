package stepdefinitions;

import Utilities.GlobalParamsFactory;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

public class BaseTest extends GlobalParamsFactory
{

    @BeforeAll
    static void setupChromedriver() {

    }

    @BeforeEach
    public void setUp() throws Exception {
        SetupBrowser();
    }

    @AfterEach
    public void tearDown() throws Exception {
      //  Driver.close();
      //  Driver.quit();
    }

}
