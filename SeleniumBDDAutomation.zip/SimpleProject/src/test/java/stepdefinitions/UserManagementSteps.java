package stepdefinitions;

import PageObjects.Pages.HomePage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class UserManagementSteps extends BaseTest {

    @Given("I am on the user management page")
    public void iAmOnTheUserManagementPage() {
        HomePage homePage = new HomePage(driver);
        homePage.NavigateToSpecificURL(BaseUrl);
    }

    @When("I add a new user with the following detail")
    public void iAddANewUserWithTheFollowingDetail() {
        HomePage homePage = new HomePage(driver);
        homePage.clickOnAddUserLink();
        homePage.provideUserDetails(FirstName, LastName, UserName, PassWord, Role, Email, CellPhone);
    }

    @Then("I should see the user with the name in the user table")
    public void iShouldSeeTheUserWithTheNameInTheUserTable() {
        HomePage homePage = new HomePage(driver);
        homePage.validateAddedUserInTheWebtables(UserName, 0, 2);
    }

    @When("I delete {string} user with the following detail")
    public void iDeleteUserWithTheFollowingDetail(String deleteUserName) {
        HomePage homePage = new HomePage(driver);
        homePage.deleteTheUserFromTheTable(deleteUserName, 2, 2);
    }

    @Then("I should not see the user with the {string} in the user table")
    public void iShouldNotSeeTheUserWithTheInTheUserTable(String deleteUserName) {
        HomePage homePage = new HomePage(driver);
        homePage.isUserDeletedFromTable(deleteUserName, 2);
    }
}
