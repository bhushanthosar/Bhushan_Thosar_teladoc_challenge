package Utilities;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.FileInputStream;
import java.util.Properties;

import static java.lang.Integer.parseInt;

public class GlobalParamsFactory {
    public static WebDriver driver = GetDriver();
    public static int ExplicitWait;
    public static int ImplicitWait;
    public static String BaseUrl = PropertyLoader.ReadConfig().getProperty("BaseUrl");
    public static String FirstName = PropertyLoader.ReadConfig().getProperty("FirstName");
    public static String LastName = PropertyLoader.ReadConfig().getProperty("LastName");
    public static String UserName = PropertyLoader.ReadConfig().getProperty("UserName");
    public static String PassWord = PropertyLoader.ReadConfig().getProperty("PassWord");
    public static String Role = PropertyLoader.ReadConfig().getProperty("Role");
    public static String Email = PropertyLoader.ReadConfig().getProperty("Email");
    public static String CellPhone = PropertyLoader.ReadConfig().getProperty("CellPhone");
    public static String DeleteUserName = PropertyLoader.ReadConfig().getProperty("DeleteUserName");


    public static void SetupBrowser() {
        driver.manage().window().maximize();
    }

    public static WebDriver GetDriver() {
        ChromeOptions chromeOptions = new ChromeOptions();
        WebDriverManager.chromedriver().setup();
        return new ChromeDriver(chromeOptions);
    }


}
