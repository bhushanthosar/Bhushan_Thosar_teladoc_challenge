package Utilities;

import java.io.FileInputStream;
import java.util.Properties;

import static java.lang.Integer.parseInt;

public class PropertyLoader {

    public static Properties ReadConfig()
    {
        Properties properties = new Properties();
        try {
            FileInputStream configFile = new FileInputStream("src/main/resources/app.properties");

            properties.load(configFile);
        }catch (Exception e){
            e.printStackTrace();
        }
        return properties;

    }
}
