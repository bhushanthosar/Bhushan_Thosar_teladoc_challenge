package PageObjects.Pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import PageObjects.BasePage;
import org.openqa.selenium.WebElement;

import java.util.List;

public class HomePage extends BasePage {
    private By addUserLink = By.xpath("//button[@ng-click='pop()' and @type='add']");
    private By addUserModelHeader = By.xpath("//*[text()='Add User']");
    private By firstNameTextbox = By.xpath("//input[@name='FirstName']");
    private By lastNameTextbox = By.xpath("//input[@name='LastName']");
    private By userNameTextbox = By.xpath("//input[@name='UserName']");
    private By passwordTextbox = By.xpath("//input[@name='Password']");
    private By customerCompanyAAARadioButton = By.xpath("//label[text()='Company AAA']");
    private By roleDropdown = By.xpath("//select[@name='RoleId']");
    private By emailTextbox = By.xpath("//input[@name='Email']");
    private By cellPhoneTextbox = By.xpath("//input[@name='Mobilephone']");
    private By saveButton = By.xpath("//button[text()='Save']");
    private By cancelButton = By.xpath("//button[text()='Close']");
    private By tableLocator = By.xpath("//table[@table-title='Smart Table example']//tbody");
    private By deleteButtonLocator = By.xpath("//button[@ng-click='delUser()']");
    private By okButton = By.xpath("//button[text()='OK']");


    public HomePage(WebDriver driver) {
        super(driver);

    }

    public void NavigateToSpecificURL(String url) {
        driver.manage().window().maximize();
        driver.navigate().to(url);
    }

    public void clickOnAddUserLink() {
        ClickOnElement(addUserLink);
        WaitUntilElementAppear(addUserModelHeader);
    }

    public void provideUserDetails(String FirstName, String LastName, String UserName, String PassWord, String Role, String Email, String CellPhone) {
        WaitUntilElementAppear(firstNameTextbox);
        TypeInsideTheElement(firstNameTextbox, FirstName);
        TypeInsideTheElement(lastNameTextbox, LastName);
        TypeInsideTheElement(userNameTextbox, UserName);
        TypeInsideTheElement(passwordTextbox, PassWord);
        ClickOnElement(customerCompanyAAARadioButton);
        SelectDropdownValue(roleDropdown, Role);
        TypeInsideTheElement(emailTextbox, Email);
        TypeInsideTheElement(cellPhoneTextbox, CellPhone);
        ClickOnElement(saveButton);
    }

    public void validateAddedUserInTheWebtables(String FirstName, int rowNumber, int columnNumber) {
        WebElement table = driver.findElement(tableLocator);
        WebElement row = table.findElements(By.tagName("tr")).get(rowNumber);
        WebElement cell = row.findElements(By.tagName("td")).get(columnNumber);
        String firstName = cell.getText();
        Assert.assertEquals(firstName, FirstName);
    }

    public void deleteTheUserFromTheTable(String searchText, int rowIndex, int cellIndex) {
        List<WebElement> rows = driver.findElement(tableLocator).findElements(By.tagName("tr"));

        // Log the number of rows
        System.out.println("Number of rows: " + rows.size());

        if (rowIndex >= rows.size()) {
            throw new IndexOutOfBoundsException("Row index " + rowIndex + " out of bounds for table with " + rows.size() + " rows.");
        }

        List<WebElement> cells = rows.get(rowIndex).findElements(By.tagName("td"));

        // Log the number of columns in the row
        System.out.println("Number of columns in row " + rowIndex + ": " + cells.size());

        if (cellIndex >= cells.size()) {
            throw new IndexOutOfBoundsException("Cell index " + cellIndex + " out of bounds for row with " + cells.size() + " columns.");
        }

        if (cells.get(cellIndex).getText().equals(searchText)) {
            cells.get(cellIndex).findElement(deleteButtonLocator).click();
            ClickOnElement(okButton);
            System.out.println("Deleted the row with the text: " + searchText);
        } else {
            throw new NoSuchElementException("No matching text found in the specified cell.");
        }
    }

    public boolean isUserDeletedFromTable(String searchText, int cellIndex) {
        List<WebElement> rows = driver.findElement(tableLocator).findElements(By.tagName("tr"));

        for (WebElement row : rows) {
            List<WebElement> cells = row.findElements(By.tagName("td"));
            if (cells.size() > cellIndex && cells.get(cellIndex).getText().equals(searchText)) {
                return false; // User is still present
            }
        }
        return true; // User is deleted
    }
}
