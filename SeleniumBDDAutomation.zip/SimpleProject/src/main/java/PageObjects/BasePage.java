package PageObjects;

import Helpers.SeleniumHelpers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BasePage extends SeleniumHelpers
{

    public BasePage(WebDriver driver)
    {
        super(driver);
        this.driver = driver;
    }

    protected WebDriver driver;

    private By AcceptCookiesButton = By.cssSelector("#onetrust-accept-btn-handler");

    //cookies are not mandatory
    public void AcceptCookies()
    {
        WaitForOptionalElement(AcceptCookiesButton);
        ClickOnElement(AcceptCookiesButton);
    }

}
