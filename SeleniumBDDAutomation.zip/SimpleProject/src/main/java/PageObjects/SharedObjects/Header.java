package PageObjects.SharedObjects;

import PageObjects.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Header extends BasePage
{
    public Header(WebDriver driver)
    {
        super(driver);
    }

    private By JustAnotherLocator = By.cssSelector("just another locator");
}
