# Selenium Java BDD Cucumber Framework

## Introduction
This project is a Selenium framework built using Java and Cucumber for BDD (Behavior-Driven Development) testing. The framework supports writing tests in Gherkin syntax to improve readability and collaboration with non-technical stakeholders.

## Prerequisites
- Java JDK 8 or above
- Maven
- IDE (IntelliJ IDEA, etc.)
- Browser (Chrome, Firefox, etc.)

## Project Setup

1. Clone the repository
   git clone https://github.com/your-username/selenium-cucumber-bdd-framework.git
   cd selenium-cucumber-bdd-framework

2. Import the project into your IDE
Open your IDE.
Import the project as a Maven project.

3. Install dependencies
   mvn clean install

4. Writing Tests
   Feature Files:
   Feature files are written in Gherkin syntax and located in the src/test/resources/features directory
   Step Definitions:
   Step definitions are located in the src/test/java/stepdefinitions directory. 
    
5. Running the Tests
    Run it from CucumberTestRunner as Junit test